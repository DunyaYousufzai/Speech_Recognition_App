import tensorflow as tf
from mapping import _mapping
from tensorflow.keras.models import load_model
import numpy as np

model = load_model('speechmodel.hdf5')
SAVED_MODEL_PATH = "speechmodel.hdf5"


class _keywords:
    """Singleton class for keyword spotting inference with trained models.
    :param model: Trained model
    """
    model = None
    _instance = None

    def predict(self, audio):
        """
        :param file_path (str): Path to audio file to predict
        :return predicted_keyword (str): Keyword predicted by the model
        """

        prob = self.model.predict(audio.reshape(1, 8000, 1))
        index = np.argmax(prob[0])
        if(prob[0][np.argmax(prob[0])]) < 0.85:
            return "شناخته نشد"
        print(prob[0][np.argmax(prob[0])])
        predicted_keyword = _mapping[index]
        return predicted_keyword


def keywords():
    """Factory function for keywords class.
    :return _keywords._instance (_keywords):
    """

    # ensure an instance is created only the first time the factory function is called
    if _keywords._instance is None:
        _keywords._instance = _keywords()
        _keywords.model = tf.keras.models.load_model(SAVED_MODEL_PATH)
    return _keywords._instance
