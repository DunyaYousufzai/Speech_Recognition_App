import sounddevice as sd
import soundfile as sf
from modelcreate import keywords
import librosa


def record(filename):
    samplerate = 8000
    duration = 1  # seconds
    filename = filename
    print("start")
    mydata = sd.rec(int(samplerate * duration), samplerate=samplerate,
                    channels=1, blocking=True)
    print("end")
    sd.wait()
    sf.write(filename, mydata, samplerate)

# def predict(filename):
#     samples, sample_rate = librosa.load(filename, sr = 8000)
#     samples = librosa.resample(samples, sample_rate, 8000)
#     if len(samples) < sample_rate:
#         sample_rate = len(samples)
#     elif(len(samples) > sample_rate):
#         sample_rate = len(samples)
#     else:
#         sample_rate = len(samples)
#     # ipd.Audio(samples,rate=8000)
#     md = keywords()
#     word = md.predict(samples)
#     print(word)
