import tkinter as tk
from PIL import Image, ImageTk
from tkinter import *
import PIL.Image
from winsound import *
import librosa

IMAGE_PATH = './imgs/1.jpg'
IMAGE_PATH2 = './imgs/bg3.png'
IMAGE_PATH3 = './imgs/voice2.jpg'
WIDTH = 1000
HEIGTH = 600


class Page(tk.Frame):
    def __init__(self, *args, **kwargs):
        tk.Frame.__init__(self, *args, **kwargs)

    def show(self):
        self.lift()


class Page1(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)

        canvas = tk.Canvas(self, width=WIDTH, height=HEIGTH)
        canvas.pack()
        img = ImageTk.PhotoImage(PIL.Image.open(IMAGE_PATH).resize(
            (WIDTH, HEIGTH), PIL.Image.ANTIALIAS))
        # Keep a reference in case this code is put in a function.
        canvas.background = img
        bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)

        param1 = StringVar()
        param2 = StringVar()
        param3 = DoubleVar()
        param4 = IntVar()
        param5 = StringVar()
        param6 = StringVar()
        param7 = StringVar()
        param8 = IntVar()

        def trainingstart():
            var1 = param1.get()
            var2 = param2.get()
            var3 = param3.get()
            var4 = param4.get()
            var5 = param5.get()
            var6 = param6.get()
            var7 = param7.get()
            var8 = param8.get()

            import speech
            sp = speech.speech_with_CNN()
            sp.load_data("/dataset",  var1, var2)
            sp.count("/dataset/")
            sp.waves_labels()
            sp.split(var3, var4)
            sp.model(var5, var6, var7, var8)
            sp.visualize()

        title = tk.Label(self, text="Welcome, Please Write the Appropriate Parameters", font=(
            "Bunch Blossoms Personal Use", 12, "bold"))
        title.place(x=10, y=7, width=530,  height=40)

        label1 = tk.Label(self, text="/subfolder/file.wav/",
                          font=("calibre", 12, "bold"))
        label1.place(x=10, y=50, width=250, height=40)
        entry1 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param1, fg="blue")
        entry1.place(x=290, y=50, width=250, height=40)

        label2 = tk.Label(self, text="Title", font=("calibre", 12, "bold"))
        label2.place(x=10, y=100, width=250, height=40)
        entry2 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param2, fg="blue")
        entry2.place(x=290, y=100, width=250, height=42)

        label3 = tk.Label(self, text="Test Size", font=("calibre", 12, "bold"))
        label3.place(x=10, y=150, width=250, height=40)
        entry3 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param3, fg="blue")
        entry3.place(x=290, y=150, width=250, height=42)

        label4 = tk.Label(self, text="Random State",
                          font=("calibre", 12, "bold"))
        label4.place(x=10, y=200, width=250, height=40)
        entry4 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param4, fg="blue")
        entry4.place(x=290, y=200, width=250, height=42)

        label5 = tk.Label(self, text="Loss", font=("calibre", 12, "bold"))
        label5.place(x=10, y=250, width=250, height=40)
        entry5 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param5, fg="blue")
        entry5.place(x=290, y=250, width=250, height=42)

        label6 = tk.Label(self, text="Optimizer", font=("calibre", 12, "bold"))
        label6.place(x=10, y=300, width=250, height=40)
        entry6 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param6, fg="blue")
        entry6.place(x=290, y=300, width=250, height=42)

        label7 = tk.Label(self, text="Metrics", font=("calibre", 12, "bold"))
        label7.place(x=10, y=350, width=250, height=40)
        entry7 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param7, fg="blue")
        entry7.place(x=290, y=350, width=250, height=42)

        label8 = tk.Label(self, text="Epochs", font=("calibre", 12, "bold"))
        label8.place(x=10, y=400, width=250, height=40)
        entry8 = tk.Entry(self, font=("calibre", 12, "bold"),
                          textvariable=param8, fg="blue")
        entry8.place(x=290, y=400, width=250, height=42)

        def back():
            root.destroy()
            from subprocess import call
            call(["python", "speech.py"])

        button1 = tk.Button(self, text="Back", font=(
            "calibre", 12, "bold"), bg="lightblue", command=back)
        button1.place(x=80, y=480, width=110, height=40)

        button2 = tk.Button(self, text="Start training", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=trainingstart)
        button2.place(x=355, y=480, width=130, height=40)


class Page2(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        canvas = tk.Canvas(self, width=WIDTH, height=HEIGTH)
        canvas.pack()
        img = ImageTk.PhotoImage(PIL.Image.open(IMAGE_PATH2).resize(
            (WIDTH, HEIGTH), PIL.Image.ANTIALIAS))
        # Keep a reference in case this code is put in a function.
        canvas.background = img
        bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)
        title = tk.Label(self, text="Try to choose each parameter carefully\nDo not put\nComma;\nsemicolon;\nSpaces;\n&\nQuotation Mark;",
                         font=("times new roman", 20, "bold"), fg="black")
        title.place(x=5, y=5, width=510,  height=550)


class Page3(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        canvas = tk.Canvas(self, width=WIDTH, height=HEIGTH)
        canvas.pack()
        img = ImageTk.PhotoImage(PIL.Image.open(IMAGE_PATH3).resize(
            (WIDTH, HEIGTH), PIL.Image.ANTIALIAS))
        # Keep a reference in case this code is put in a function.
        canvas.background = img
        bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)

        def recordword():
            import useModel
            from modelcreate import keywords
            useModel.record("recordaudio.wav")

        def predictword():
            def predict(filename):
                from modelcreate import keywords
                samples, sample_rate = librosa.load(filename, sr=8000)
                samples = librosa.resample(samples, sample_rate, 8000)
                if len(samples) < sample_rate:
                    sample_rate = len(samples)
                elif(len(samples) > sample_rate):
                    sample_rate = len(samples)
                else:
                    sample_rate = len(samples)
                # ipd.Audio(samples,rate=8000)
                md = keywords()
                word = md.predict(samples)
                label1 = tk.Label(
                    self, text=word, font=("calibre", 12, "bold"))
                label1.place(x=710, y=400, width=210, height=40)
                # print(word)
            predict('recordaudio.wav')

        button1 = tk.Button(self, text="Record", font=(
            "calibre", 12, "bold"), bg="lightblue", command=recordword)
        button1.place(x=80, y=40, width=210, height=140)
        def play(): return PlaySound('recordaudio.wav', SND_FILENAME)
        button2 = tk.Button(self, text="Play", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=play)
        button2.place(x=80, y=340, width=210, height=140)

        button3 = tk.Button(self, text="Predict", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=predictword)
        button3.place(x=710, y=220, width=210, height=140)


class MainView(tk.Frame):
    def __init__(self, *args, **kwargs):
        tk.Frame.__init__(self, *args, **kwargs)
        p1 = Page1(self)
        p2 = Page2(self)
        p3 = Page3(self)

        buttonframe = tk.Frame(self)
        container = tk.Frame(self)
        buttonframe.pack(side="top", fill="x", expand=False)
        container.pack(side="top", fill="both", expand=True)

        p1.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
        p2.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
        p3.place(in_=container, x=0, y=0, relwidth=1, relheight=1)

        b1 = tk.Button(buttonframe, text="Training", bg="pink",
                       font=("Arial", 14), command=p1.lift)
        b2 = tk.Button(buttonframe, text="Tips", bg="lightblue",
                       font=("Arial", 14), command=p2.lift)
        b3 = tk.Button(buttonframe, text="Test", bg="#CBC3E3",
                       font=("Arial", 14), command=p3.lift)

        b1.pack(side="left")
        b2.pack(side="left")
        b3.pack(side="left")

        p1.show()


if __name__ == "__main__":
    root = tk.Tk()
    main = MainView(root)
    main.pack(side="top", fill="both", expand=True)
    window_width = 1000
    window_height = 600
    root.title('Speech Training')
    root.geometry("1000x600")
    root.configure(background="black")
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x_cordinate = int((screen_width/2) - (window_width/2))
    y_cordinate = int((screen_height/2) - (window_height/2))
    root.geometry("{}x{}+{}+{}".format(window_width,
                                       window_height, x_cordinate, y_cordinate))
    root.resizable(False, False)
    p1 = PhotoImage(file="./icons/icon.png")
    root.iconphoto(False, p1)
    root.mainloop()
