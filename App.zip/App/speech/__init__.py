from speech.main import speech_with_CNN
# from speech.useModel import record, predict


