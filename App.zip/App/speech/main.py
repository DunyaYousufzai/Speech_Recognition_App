import os
import librosa
import IPython.display as ipd
import matplotlib.pyplot as plt
import numpy as np
from scipy.io import wavfile
import warnings
warnings.filterwarnings("ignore")
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from tensorflow.keras.layers import Dense, Dropout, Flatten, Conv1D, Input, MaxPooling1D
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras import backend as K
K.clear_session()
import random
import json


class speech_with_CNN:
    def __init__(self):
        pass
    def load_data(self, filename,path, title):
        global samples, sample_rate , train_audio_path
        train_audio_path = os.getcwd()+filename
        samples, sample_rate = librosa.load(train_audio_path+path, sr = 8000)
        if len(samples) < sample_rate:
            sample_rate = len(samples)
        elif(len(samples) > sample_rate):
            sample_rate = len(samples)
        else:
            sample_rate = len(samples)

        fig = plt.figure(figsize=(14, 8))
        ax1 = fig.add_subplot(211)
        ax1.set_title(title)
        ax1.set_xlabel('time')
        ax1.set_ylabel('Amplitude')
        ax1.plot(np.linspace(0, sample_rate/len(samples), sample_rate), samples)
        plt.show()
        print(sample_rate)

    def count(self, dataset):
        #find count of each label and plot bar graph
        global labels, waves, all_wave, y
        labels=os.listdir(train_audio_path)
        labels = [d for d in labels if os.path.isdir(os.getcwd()+dataset+d)]
        print(train_audio_path)
        print(labels)
        no_of_recordings=[]
        for label in labels:
            waves = [f for f in os.listdir(train_audio_path + '/'+ label) if f.endswith('.wav')]
            no_of_recordings.append(len(waves))
        #plot
        plt.figure(figsize=(30,5))
        index = np.arange(len(labels))
        plt.bar(index, no_of_recordings)
        plt.xlabel('Commands', fontsize=12)
        plt.ylabel('No of recordings', fontsize=12)
        plt.xticks(index, labels, fontsize=15, rotation=60)
        plt.title('No. of recordings for each sample')
        plt.show()

    def waves_labels(self):
        global all_label, all_wave, data3, y
        all_wave = []
        all_label = []
        for label in labels:
            print(label)
            waves = [f for f in os.listdir(train_audio_path + '/'+ label) if f.endswith('.wav')]
            for wav in waves:
                samples, sample_rate = librosa.load(train_audio_path + '/' + label + '/' + wav, sr = 16000)
                samples = librosa.resample(samples, sample_rate, 8000)
                samples = samples[:8000]
                if(len(samples)== 8000) : 
                    all_wave.append(samples)
                    all_label.append(label)
        with open("file.txt", "a", encoding = "utf-8") as f:
            f.write(str(all_label))
        with open("all_wave.txt", "a", encoding = "utf-8") as f:
            f.write(str(all_wave))

        # from file import  all_label
        le = LabelEncoder()
        y=le.fit_transform(all_label)
        data3 = {
        " classes" :[]
        }
        data3['classes']= list(le.classes_)
        y=to_categorical(y, num_classes=len(labels))
        all_wave = np.array(all_wave).reshape(-1,8000,1)
        with open("data.json", "w") as fp:
            json.dump(data3, fp, indent=4)

    def split(self, test_size, random_state):
        global x_tr, x_val, y_tr, y_val
        x_tr, x_val, y_tr, y_val = train_test_split(np.array(all_wave),np.array(y),stratify=y,test_size = test_size,random_state=random_state,shuffle=True)
    
    def model(self, loss, optimizer, metrics, epochs):
        global history
        inputs = Input(shape=(8000,1))
        conv = Conv1D(8,13, padding='valid', activation='relu', strides=1)(inputs)
        conv = MaxPooling1D(3)(conv)
        conv = Dropout(0.3)(conv)

        conv = Conv1D(16, 11, padding='valid', activation='relu', strides=1)(conv)
        conv = MaxPooling1D(3)(conv)
        conv = Dropout(0.3)(conv)


        conv = Conv1D(32, 9, padding='valid', activation='relu', strides=1)(conv)
        conv = MaxPooling1D(3)(conv)
        conv = Dropout(0.3)(conv)


        conv = Conv1D(64, 7, padding='valid', activation='relu', strides=1)(conv)
        conv = MaxPooling1D(3)(conv)
        conv = Dropout(0.3)(conv)

        conv = Flatten()(conv)

        conv = Dense(256, activation='relu')(conv)
        conv = Dropout(0.3)(conv)


        conv = Dense(128, activation='relu')(conv)
        conv = Dropout(0.3)(conv)

        outputs = Dense(len(labels), activation='softmax')(conv)

        model = Model(inputs, outputs)
        model.summary()
        model.compile(loss=loss,optimizer=optimizer,metrics=[metrics])
        es = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=10, min_delta=0.0001) 
        mc = ModelCheckpoint('model.hdf5', monitor='val_acc', verbose=1, save_best_only=True, mode='max')
        history=model.fit(x_tr, y_tr ,epochs=epochs, callbacks=[es,mc], batch_size=32, validation_data=(x_val,y_val))
        model.save('speechmodel.hdf5')
        

    def visualize(self):
        plt.plot(history.history['loss'], label='train')
        plt.plot(history.history['val_loss'], label='test')
        plt.legend()
        plt.show()


          

# sp = speech_with_CNN()
# sp.load_data("/dataset",  '/دنیا/dunya-3.wav' , "Bahez")
# sp.count("/dataset/")
# sp.waves_labels()
# sp.split(0.17, 777)
# sp.model('categorical_crossentropy', "adam" , "accuracy", 60)
# sp.visualize()

