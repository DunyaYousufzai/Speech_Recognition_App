from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
from tkinter import ttk
import webbrowser


class speech(Frame):
    def __init__(self, master, *pargs):
        Frame.__init__(self, master, *pargs)
        self.image = Image.open("./imgs/voice.jpg")
        self.img_copy = self.image.copy()
        self.background_image = ImageTk.PhotoImage(self.image)
        self.background = Label(self, image=self.background_image)
        self.background.pack(fill=BOTH, expand=YES)
        self.background.bind('<Configure>', self._resize_image)

    def window(self):
        root2.title("Speech Recognition")
        window_width = 1000
        window_height = 600
        root2.geometry("1000x600")
        root2.configure(background="black")
        screen_width = root2.winfo_screenwidth()
        screen_height = root2.winfo_screenheight()
        x_cordinate = int((screen_width/2) - (window_width/2))
        y_cordinate = int((screen_height/2) - (window_height/2))
        root2.geometry("{}x{}+{}+{}".format(window_width,
                                            window_height, x_cordinate, y_cordinate))
        root2.resizable(False, False)
        p1 = PhotoImage(file="./icons/icon.png")
        root2.iconphoto(False, p1)

    def trainingsp(self):
        root2.destroy()
        from subprocess import call
        call(["python", "trainingspeech.py"])

    def simpletraining(self):
        root2.destroy()
        from subprocess import call
        call(["python", "simplespeech.py"])

    def _resize_image(self, event):
        translator_width = event.width
        translator_height = event.height
        self.image = self.img_copy.resize(
            (translator_width, translator_height))
        self.background_image = ImageTk.PhotoImage(self.image)
        self.background.configure(image=self.background_image)

        stl = ttk.Style()
        stl.configure('C.TLabel', padding=[
                      10, 10, 10, 10], font=('"times new roman"', 13))
        stl.map('C.TLabel',
                foreground=[('pressed', 'white'), ('active', 'white')],
                background=[('pressed', '!disabled', 'darkblue'),
                            ('active', 'black')],
                relief=[('pressed', 'sunken'),
                        ('!pressed', 'raised')],

                )

        button2 = ttk.Button(
            root2, text='Click here to start training', style='C.TLabel', command=self.trainingsp)
        button2.place(x=450, y=100, width=220, height=220)
        button3 = ttk.Button(
            root2, text='Click here to start simple\ntraining', style='C.TLabel', command=self.simpletraining)
        button3.place(x=700, y=100, width=220, height=220)

    def about(self):
        messagebox.showinfo(
            'Sunshine',  'The project created by sunshine team')

    def translator(self):
        root2.destroy()
        from subprocess import call
        call(["python", "translator.py"])

    def mainpage(self):
        root2.destroy()
        from subprocess import call
        call(["python", "main.py"])

    def menubar(self):
        menubar = Menu(root2, background='#ff8000', foreground='black',
                       activebackground='white', activeforeground='black')
        file = Menu(menubar, tearoff=0,
                    background="#FFFFFF", foreground='black')
        file.add_command(label="Speech Recognition")
        file.add_command(label="Language Translation", command=self.translator)
        file.add_command(label="Main Page", command=self.mainpage)

        file.add_separator()
        file.add_command(label="Exit", command=root2.quit)
        menubar.add_cascade(label="Start", menu=file)

        help = Menu(menubar, tearoff=0)
        help.add_command(label="About", command=self.about)
        menubar.add_cascade(label="Help", menu=help)

        root2.config(menu=menubar)


root2 = Tk()


def main():
    e = speech(root2)
    e.menubar()
    e.pack(fill=BOTH, expand=YES)
    e.window()
    root2.mainloop()


if __name__ == "__main__":
    main()
