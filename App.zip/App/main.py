from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
from tkinter import ttk
import webbrowser

root = Tk()


class new(Frame):
    def __init__(self, master, *pargs):
        Frame.__init__(self, master, *pargs)
        self.image = Image.open("./imgs/bg1.png")
        self.img_copy = self.image.copy()
        self.background_image = ImageTk.PhotoImage(self.image)
        self.background = Label(self, image=self.background_image)
        self.background.pack(fill=BOTH, expand=YES)
        self.background.bind('<Configure>', self._resize_image)

    def window(self):
        root.title("SunshineApp")
        window_width = 1000
        window_height = 600
        root.geometry("1000x600")
        root.configure(background="black")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x_cordinate = int((screen_width/2) - (window_width/2))
        y_cordinate = int((screen_height/2) - (window_height/2))
        root.geometry("{}x{}+{}+{}".format(window_width,
                                           window_height, x_cordinate, y_cordinate))
        root.resizable(False, False)
        p1 = PhotoImage(file="./icons/sun.png")
        root.iconphoto(False, p1)

    def _resize_image(self, event):
        new_width = event.width
        new_height = event.height
        self.image = self.img_copy.resize((new_width, new_height))
        self.background_image = ImageTk.PhotoImage(self.image)
        self.background.configure(image=self.background_image)

        def OpenUrl():
            webbrowser.open_new(
                "https://www.researchgate.net/publication/352091132_Dunya_Yousufzai_Early_Stages_of_Automatic_Speech_Recognition_ASR_in_Non-English_Speaking_Countries_and_Factors_That_Affect_the_Recognition_Process")

        stl = ttk.Style()
        stl.configure('C.TLabel', padding=[10, 10, 10, 10])
        stl.map('C.TLabel',
                foreground=[('pressed', 'purple'), ('active', 'black')],
                background=[('pressed', '!disabled', 'pink'),
                            ('active', 'white')],
                relief=[('pressed', 'sunken'),
                        ('!pressed', 'raised')]
                )
        button2 = ttk.Button(
            root, text='Click here to read the Article', style='C.TLabel', command=OpenUrl)
        button2.place(x=420, y=500)

        user_name = Label(root,
                          text="Click the Start Menu to Start the Training",  width=42, height=0, highlightbackground="black", highlightcolor="black", highlightthickness=0, bd=0,  fg="black",
                          bg="pink",
                          font=("Sinami", 25))

        def move(i):
            if i <= 90:
                user_name.place(x=i, y=i)
                user_name.after(100, lambda: move(i))  # after every 100ms
                i = i+1
        move(0)  # Start animation instantly

    def about(self):
        messagebox.showinfo(
            'Sunshine', 'The project created by sunshine team')

    def speech(self):
        root.destroy()
        from subprocess import call
        call(["python", "speech.py"])

    def translate(self):
        root.destroy()
        from subprocess import call
        call(["python", "translator.py"])

    def menubar(self):
        menubar = Menu(root, background='#ff8000', foreground='black',
                       activebackground='white', activeforeground='black')
        file = Menu(menubar, tearoff=0,
                    background="#FFFFFF", foreground='black')
        file.add_command(label="Speech Recognition", command=self.speech)
        file.add_command(label="Language Translation", command=self.translate)

        file.add_separator()
        file.add_command(label="Exit", command=root.quit)
        menubar.add_cascade(label="Start", menu=file)

        help = Menu(menubar, tearoff=0)
        help.add_command(label="About", command=self.about)
        menubar.add_cascade(label="Help", menu=help)

        root.config(menu=menubar)


def main():
    e = new(root)
    e.menubar()
    e.pack(fill=BOTH, expand=YES)
    e.window()
    root.mainloop()


if __name__ == "__main__":
    main()
