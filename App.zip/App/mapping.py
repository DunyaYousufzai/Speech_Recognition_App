_mapping = [
        "\u062f\u0646\u06cc\u0627"
]