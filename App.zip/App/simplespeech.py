
import tkinter as tk
from PIL import Image, ImageTk
from tkinter import *
import PIL.Image
from winsound import *
import librosa
import sounddevice as sd
import soundfile as sf

IMAGE_PATH = './imgs/simple.jpg'
WIDTH = 1000
HEIGTH = 600


class Page(tk.Frame):
    def __init__(self, *args, **kwargs):
        tk.Frame.__init__(self, *args, **kwargs)

    def show(self):
        self.lift()


class Page1(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)

        canvas = tk.Canvas(self, width=WIDTH, height=HEIGTH)
        canvas.pack()
        img = ImageTk.PhotoImage(PIL.Image.open(IMAGE_PATH).resize(
            (WIDTH, HEIGTH), PIL.Image.ANTIALIAS))
        # Keep a reference in case this code is put in a function.
        canvas.background = img
        bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)

        def recordword():
            def record(filename):
                samplerate = 8000
                duration = 1  # seconds
                filename = filename
                print("start")
                mydata = sd.rec(int(samplerate * duration), samplerate=samplerate,
                                channels=1, blocking=True)
                print("end")
                sd.wait()
                sf.write(filename, mydata, samplerate)
            record("simpleaudio.wav")

        def predictword():
            from key_spoting_service import Keyword_Spotting_Service
            kss = Keyword_Spotting_Service()
            keyword = kss.predict("simpleaudio.wav")
            print("keyword: ", keyword)
            label1 = tk.Label(
                self, text=keyword, font=("calibre", 12, "bold"), bg="pink")
            label1.place(x=710, y=495, width=210, height=40)

        def trainingstart():
            from simplespeech import main, preprocess_dataset
            preprocess_dataset("SimpleDataset", 'simpledata.json')
            main()

        title = tk.Label(self, text="Welcome to Speech Recognition System", bd=9, relief=GROOVE,
                         font=("times new roman", 20, "bold"), bg="white", fg="green")
        title.place(x=240, y=17, width=530,  height=80)

        def back():
            root.destroy()
            from subprocess import call
            call(["python", "speech.py"])

        button = tk.Button(self, text="⬅️", font=(
            "calibre", 12, "bold"), bg="lightblue", command=back)
        button.place(x=10, y=530, width=40, height=40)

        button1 = tk.Button(self, text="Start Training", font=(
            "calibre", 12, "bold"), bg="lightblue", command=trainingstart)
        button1.place(x=80, y=140, width=210, height=140)

        button2 = tk.Button(self, text="Record", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=recordword)
        button2.place(x=80, y=340, width=210, height=140)

        def play(): return PlaySound('simpleaudio.wav', SND_FILENAME)
        button3 = tk.Button(self, text="Play", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=play)
        button3.place(x=710, y=140, width=210, height=140)

        button4 = tk.Button(self, text="Predict", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=predictword)
        button4.place(x=710, y=340, width=210, height=140)


class MainView(tk.Frame):
    def __init__(self, *args, **kwargs):
        tk.Frame.__init__(self, *args, **kwargs)
        p1 = Page1(self)
        buttonframe = tk.Frame(self)
        container = tk.Frame(self)
        buttonframe.pack(side="top", fill="x", expand=False)
        container.pack(side="top", fill="both", expand=True)

        p1.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
        p1.show()


if __name__ == "__main__":
    root = tk.Tk()
    main = MainView(root)
    main.pack(side="top", fill="both", expand=True)
    window_width = 1000
    window_height = 600
    root.title('Speech Training')
    root.geometry("1000x600")
    root.configure(background="black")
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x_cordinate = int((screen_width/2) - (window_width/2))
    y_cordinate = int((screen_height/2) - (window_height/2))
    root.geometry("{}x{}+{}+{}".format(window_width,
                                       window_height, x_cordinate, y_cordinate))
    root.resizable(False, False)
    p1 = PhotoImage(file="./icons/icon.png")
    root.iconphoto(False, p1)
    root.mainloop()
