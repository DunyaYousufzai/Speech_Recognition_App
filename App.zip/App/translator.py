from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
from tkinter import ttk
import webbrowser
import tkinter as tk


class translator(Frame):
    def __init__(self, master, *pargs):
        Frame.__init__(self, master, *pargs)
        self.image = Image.open("./imgs/lang.png")
        self.img_copy = self.image.copy()
        self.background_image = ImageTk.PhotoImage(self.image)
        self.background = Label(self, image=self.background_image)
        self.background.pack(fill=BOTH, expand=YES)
        self.background.bind('<Configure>', self._resize_image)

    def traininglanguage(self):
        param1 = IntVar()
        param2 = StringVar()
        param3 = StringVar()
        param4 = IntVar()
        param5 = IntVar()
        param6 = StringVar()
        param7 = IntVar()
        param8 = StringVar()
        param9 = DoubleVar()
        param10 = IntVar()
        param11 = DoubleVar()
        param12 = StringVar()
        param13 = IntVar()
        param14 = IntVar()
        param15 = DoubleVar()

        def trainingstart():
            var1 = param1.get()
            var2 = param2.get()
            var3 = param3.get()
            var4 = param4.get()
            var5 = param5.get()
            var6 = param6.get()
            var7 = param7.get()
            var8 = param8.get()
            var9 = param9.get()
            var10 = param10.get()
            var11 = param11.get()
            var12 = param12.get()
            var13 = param13.get()
            var14 = param14.get()
            var15 = param15.get()

            from LangaugeTrans import main
            translator = main.language_translator()
            translator.select_data("words.txt", var1)
            translator.remove_punc()
            translator.convert_text_lower_case()
            translator.visualize(var2, var3, var4)
            translator.lang1_tokenizer(var5, var6)
            translator.lang2_tokenizer(var7, var8)
            translator.prepare(var9, var10)
            translator.model_compile(var11, var12)
            translator.train('translation_model.h1', var13, var14, var15)
            translator.result_plot()
            translator.load_model('translation_model.h1')
            translator.show_result()

        title = tk.Label(root2, text="Welcome, Please Write the Appropriate Parameters", bd=9, relief=GROOVE,
                         font=("times new roman", 15, "bold"), bg="white", fg="blue")
        title.place(x=250, y=15, width=530,  height=70)
        label1 = tk.Label(root2, text="Number of words",
                          font=("calibre", 12, "bold"))
        label1.place(x=10, y=100, width=230, height=40)
        entry1 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param1, fg="blue")
        entry1.place(x=255, y=100, width=230, height=40)
        label2 = tk.Label(root2, text="1st Language",
                          font=("calibre", 12, "bold"))
        label2.place(x=10, y=150, width=230, height=40)
        entry2 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param2, fg="blue")
        entry2.place(x=255, y=150, width=230, height=42)
        label3 = tk.Label(root2, text="2nd Language",
                          font=("calibre", 12, "bold"))
        label3.place(x=10, y=200, width=230, height=40)
        entry3 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param3, fg="blue")
        entry3.place(x=255, y=200, width=230, height=42)
        label4 = tk.Label(root2, text="Bins",
                          font=("calibre", 12, "bold"))
        label4.place(x=10, y=250, width=230, height=40)
        entry4 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param4, fg="blue")
        entry4.place(x=255, y=250, width=230, height=42)
        label5 = tk.Label(root2, text="Length", font=("calibre", 12, "bold"))
        label5.place(x=10, y=300, width=230, height=40)
        entry5 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param5, fg="blue")
        entry5.place(x=255, y=300, width=230, height=42)
        label6 = tk.Label(root2, text="Language", font=("calibre", 12, "bold"))
        label6.place(x=10, y=350, width=230, height=40)
        entry6 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param6, fg="blue")
        entry6.place(x=255, y=350, width=230, height=42)
        label7 = tk.Label(root2, text="Length", font=("calibre", 12, "bold"))
        label7.place(x=10, y=400, width=230, height=40)
        entry7 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param7, fg="blue")
        entry7.place(x=255, y=400, width=230, height=42)
        label8 = tk.Label(root2, text="Langauge", font=("calibre", 12, "bold"))
        label8.place(x=10, y=450, width=230, height=40)
        entry8 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param8, fg="blue")
        entry8.place(x=255, y=450, width=230, height=42)
        label9 = tk.Label(root2, text="Test Size",
                          font=("calibre", 12, "bold"))
        label9.place(x=500, y=100, width=230, height=40)
        entry9 = tk.Entry(root2, font=("calibre", 12, "bold"),
                          textvariable=param9, fg="blue")
        entry9.place(x=740, y=100, width=230, height=40)
        label10 = tk.Label(root2, text="Random State",
                           font=("calibre", 12, "bold"))
        label10.place(x=500, y=150, width=230, height=40)
        entry10 = tk.Entry(root2, font=("calibre", 12, "bold"),
                           textvariable=param10, fg="blue")
        entry10.place(x=740, y=150, width=230, height=42)
        label11 = tk.Label(root2, text="Learning Rate",
                           font=("calibre", 12, "bold"))
        label11.place(x=500, y=200, width=230, height=40)
        entry11 = tk.Entry(root2, font=("calibre", 12, "bold"),
                           textvariable=param11, fg="blue")
        entry11.place(x=740, y=200, width=230, height=42)
        label12 = tk.Label(root2, text="Loss",
                           font=("calibre", 12, "bold"))
        label12.place(x=500, y=250, width=230, height=40)
        entry12 = tk.Entry(root2, font=("calibre", 12, "bold"),
                           textvariable=param12, fg="blue")
        entry12.place(x=740, y=250, width=230, height=42)
        label13 = tk.Label(root2, text="Epochs", font=("calibre", 12, "bold"))
        label13.place(x=500, y=300, width=230, height=40)
        entry13 = tk.Entry(root2, font=("calibre", 12, "bold"),
                           textvariable=param13, fg="blue")
        entry13.place(x=740, y=300, width=230, height=42)
        label14 = tk.Label(root2, text="Batch Size",
                           font=("calibre", 12, "bold"))
        label14.place(x=500, y=350, width=230, height=40)
        entry14 = tk.Entry(root2, font=("calibre", 12, "bold"),
                           textvariable=param14, fg="blue")
        entry14.place(x=740, y=350, width=230, height=42)
        label15 = tk.Label(root2, text="Validation Split",
                           font=("calibre", 12, "bold"))
        label15.place(x=500, y=400, width=230, height=40)
        entry15 = tk.Entry(root2, font=("calibre", 12, "bold"),
                           textvariable=param15, fg="blue")
        entry15.place(x=740, y=400, width=230, height=42)

        def back():
            root2.destroy()
            from subprocess import call
            call(["python", "speech.py"])

        button = tk.Button(root2, text="⬅️", font=(
            "calibre", 12, "bold"), bg="lightblue", command=back)
        button.place(x=10, y=530, width=40, height=40)

        button2 = tk.Button(root2, text="Start training", font=(
            "calibre", 12, "bold"), bg="#CBC3E3", command=trainingstart)
        button2.place(x=500, y=450, width=471, height=40)

    def window(self):
        root2.title("Language Translator")
        window_width = 1000
        window_height = 600
        root2.geometry("1000x600")
        root2.configure(background="black")
        screen_width = root2.winfo_screenwidth()
        screen_height = root2.winfo_screenheight()
        x_cordinate = int((screen_width/2) - (window_width/2))
        y_cordinate = int((screen_height/2) - (window_height/2))
        root2.geometry("{}x{}+{}+{}".format(window_width,
                                            window_height, x_cordinate, y_cordinate))
        root2.resizable(False, False)
        p1 = PhotoImage(file="./icons/icon2.png")
        root2.iconphoto(False, p1)

    def _resize_image(self, event):
        translator_width = event.width
        translator_height = event.height
        self.image = self.img_copy.resize(
            (translator_width, translator_height))
        self.background_image = ImageTk.PhotoImage(self.image)
        self.background.configure(image=self.background_image)

    def about(self):
        messagebox.showinfo(
            'Sunshine', 'The project created by sunshine team')

    def speech(self):
        root2.destroy()
        from subprocess import call
        call(["python", "speech.py"])

    def mainpage(self):
        root2.destroy()
        from subprocess import call
        call(["python", "main.py"])

    def menubar(self):
        menubar = Menu(root2, background='#ff8000', foreground='black',
                       activebackground='white', activeforeground='black')
        file = Menu(menubar, tearoff=0,
                    background="#FFFFFF", foreground='black')
        file.add_command(label="Speech Recognition", command=self.speech)
        file.add_command(label="Language Translation")
        file.add_command(label="Main Page", command=self.mainpage)

        file.add_separator()
        file.add_command(label="Exit", command=root2.quit)
        menubar.add_cascade(label="Start", menu=file)

        help = Menu(menubar, tearoff=0)
        help.add_command(label="About", command=self.about)
        menubar.add_cascade(label="Help", menu=help)

        root2.config(menu=menubar)


root2 = Tk()


def main():
    e = translator(root2)
    e.menubar()
    e.traininglanguage()
    e.pack(fill=BOTH, expand=YES)
    e.window()
    root2.mainloop()


if __name__ == "__main__":
    main()
